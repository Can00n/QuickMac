package edu.utsa.cs3443.quickmac.model;

/*
This represents a food and all of its macronutrients.
 */
public class Food {
    private int calories;
    private double fat;
    private double protein;
    private double carbs;
    private double sugar;
    private double fiber;

    public Food(int calories, double fat, double protein, double carbs, double sugar, double fiber) {
        this.calories = calories;
        this.fat = fat;
        this.protein = protein;
        this.carbs = carbs;
        this.sugar = sugar;
        this.fiber = fiber;
    }
    //TODO: add 6 more constructors for any missing macros

    public void setCalories(int calories) {this.calories = calories;}
    public void setFat(double fat) {this.fat = fat;}
    public void setProtein(double protein) {this.protein = protein;}
    public void setCarbs(double carbs) {this.carbs = carbs;}
    public void setSugar(double sugar) {this.sugar = sugar;}
    public void setFiber(double fiber) {this.fiber = fiber;}

    public int getCalories() {return calories;}
    public double getFat() {return fat;}
    public double getProtein() {return protein;}
    public double getCarbs() {return carbs;}
    public double getSugar() {return sugar;}
    public double getFiber() {return fiber;}

    public String toString() {
        return String.format("",);
    }
}
