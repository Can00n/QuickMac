package edu.utsa.cs3443.quickmac;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class NewFoodActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_food);
    }
}