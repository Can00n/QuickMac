package edu.utsa.cs3443.quickmac;

/*
This will be the "homepage" for Quick Mac, where users can navigate to our other screens.
 */
public class MainActivity {
}
