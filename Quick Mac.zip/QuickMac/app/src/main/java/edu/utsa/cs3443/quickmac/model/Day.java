package edu.utsa.cs3443.quickmac.model;

import java.util.ArrayList;

/*
This will represent a day with all of the foods consumed in that day and the totals for each macro.
 */
public class Day {
    private String date;
    private ArrayList<Food> foods = new ArrayList<>();
    private int totalCalories;
    private double totalFat;
    private double totalProtein;
    private double totalCarbs;
    private double totalSugar;
    private double totalFiber;

    public Day(String date) {
        this.date = date;
        this.foods = new ArrayList<Food>(foods);
        this.totalCalories = 0;
        this.totalFat = 0.0;
        this.totalProtein = 0.0;
        this.totalCarbs = 0.0;
        this.totalSugar = 0.0;
        this.totalFiber = 0.0;
    }

    public void setDate(String date) {this.date = date;}
    public void setFoods(ArrayList<Food> foods) {this.foods = foods;}
    public void setTotalCalories(int totalCalories) {this.totalCalories = totalCalories;}
    public void setTotalFat(double totalFat) {this.totalFat = totalFat;}
    public void setTotalProtein(double totalProtein) {this.totalProtein = totalProtein;}
    public void setTotalCarbs(double totalCarbs) {this.totalCarbs = totalCarbs;}
    public void setTotalSugar(double totalSugar) {this.totalSugar = totalSugar;}
    public void setTotalFiber(double totalFiber) {this.totalFiber = totalFiber;}

    public String getDate(){return date;}
    public ArrayList<Food> getFoods() {return foods;}
    public int getTotalCalories() {
        for(int i = 0; i< foods.size(); i++){
            totalCalories += foods.get(i).getCalories();
        }
        return totalCalories;
    }
    public double getTotalFat() {
        for(int i = 0; i< foods.size(); i++){
            totalFat += foods.get(i).getFat();
        }
        return totalFat;
    }
    public double getTotalProtein() {
        for(int i = 0; i< foods.size(); i++){
            totalProtein += foods.get(i).getProtein();
        }
        return totalProtein;
    }
    public double getTotalCarbs() {
        for(int i = 0; i< foods.size(); i++){
            totalCarbs += foods.get(i).getCarbs();
        }
        return totalCarbs;
    }
    public double getTotalSugar() {
        for(int i = 0; i< foods.size(); i++){
            totalSugar += foods.get(i).getSugar();
        }
        return totalSugar;
    }
    public double getTotalFiber() {
        for(int i = 0; i< foods.size(); i++){
            totalFiber += foods.get(i).getFiber();
        }
        return totalFiber;
    }

    public void addFood(Food newFood) {
        if(foods != null)
            foods.add(newFood);
    }

    public void removeFood(Food outFood) {
        if(foods != null)
            foods.remove(outFood);
    }

    public String listFoods(ArrayList<Food> foods) {
        StringBuilder foodList = new StringBuilder();
        for(Food food : foods) {
            foodList.append(food);
        }
        return foodList.toString();
    }

    public String toString() {
        return String.format("%s", getDate());
    }
}
