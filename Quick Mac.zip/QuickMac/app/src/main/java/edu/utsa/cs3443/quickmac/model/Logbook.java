package edu.utsa.cs3443.quickmac.model;

/*
This represents all of the cays logged in the app.
 */
import java.util.ArrayList;

public class Logbook {
    private ArrayList<Day> days = new ArrayList<>();

    public Logbook(ArrayList<Day> days) {
        this.days = days;
    }
    public Logbook() {
        this.days = new ArrayList<Day>(days);
    }

    public void setDays(ArrayList<Day> days) {
        this.days = days;
    }

    public ArrayList<Day> getDays() {
        return days;
    }

    public void addDay(Day newDay) {
        if(days != null)
            days.add(newDay);
    }

    public void removeDay(Day outDay) {
        if(days != null)
            days.remove(outDay);
    }
}
