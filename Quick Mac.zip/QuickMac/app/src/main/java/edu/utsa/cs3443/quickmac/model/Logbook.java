package edu.utsa.cs3443.quickmac.model;

import java.util.ArrayList;

/**
 * The Logbook class represents all of the days logged in the app
 *
 * @author Canaan Eggers zko777
 */   //TODO: Import days.csv to the project and implement it correctly
public class Logbook {
    private ArrayList<Day> days = new ArrayList<>();

    /**
     * Constructor for Logbook objects
     * @param days, a list of all the days logged (ArrayList<Day>)
     */   //TODO: initialize the logbook when the app is launched
    public Logbook(ArrayList<Day> days) {
        this.days = days;
    }

    /**
     * Constructor for Logbook objects without days ArrayLists
     */
    public Logbook() {
        this.days = new ArrayList<Day>(days);
    } //is there a way for users to login and save their logbooks to them??

    /**
     * setter for days
     * @param days, a list of all the days logged (ArrayList<Day>)
     */
    public void setDays(ArrayList<Day> days) {
        this.days = days;
    }

    /**
     * getter for days
     * @return ArrayList<Day>, a list of all the days logged
     */
    public ArrayList<Day> getDays() {
        return days;
    }

    /**
     * adds a new day to days
     * @param newDay, the new Day object to be added (Day)
     */   //TODO: if user login is implemented, add the day to the logbook file
    public void addDay(Day newDay) {
        if(days != null)
            days.add(newDay);
    }

    /**
     * removes a day from days
     * @param outDay, the day to be removed (Day)
     */   //TODO: if user login is implemented, remove the day from the logbook file
    public void removeDay(Day outDay) {
        if(days != null)
            days.remove(outDay);
    }

    public String listDays(ArrayList<Day> days) {
        StringBuilder dayList = new StringBuilder();
        for(Day day : days) {
            dayList.append(day);
        }
        return dayList.toString();
    }

    public String toString() {
        return String.format("Logbook:\n%s", listDays(days));
    }
}
