package edu.utsa.cs3443.quickmac;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

import edu.utsa.cs3443.quickmac.model.Day;

public class LogbookAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<Day> days;
    private String summary;

    public LogbookAdapter(List<Day> days, String summary) {
        this.days = days;
        this.summary = summary;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == 0) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.summary_item, parent, false);
            return new SummaryViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.logbook_item, parent, false);
            return new DayViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (getItemViewType(position) == 0) {
            ((SummaryViewHolder) holder).summaryView.setText(summary);
        } else {
            Day day = days.get(position - 1);  // Adjust position for summary
            ((DayViewHolder) holder).dayView.setText(day.toString());
        }
    }

    @Override
    public int getItemCount() {
        return days.size() + 1;  // Add one for the summary view
    }

    @Override
    public int getItemViewType(int position) {
        return position == 0 ? 0 : 1;  // 0 for summary, 1 for day
    }

    public static class DayViewHolder extends RecyclerView.ViewHolder {
        public TextView dayView;

        public DayViewHolder(View itemView) {
            super(itemView);
            dayView = itemView.findViewById(R.id.textDay);
        }
    }

    public static class SummaryViewHolder extends RecyclerView.ViewHolder {
        public TextView summaryView;

        public SummaryViewHolder(View itemView) {
            super(itemView);
            summaryView = itemView.findViewById(R.id.textSummary);
        }
    }
}

