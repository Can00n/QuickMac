package edu.utsa.cs3443.quickmac;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import edu.utsa.cs3443.quickmac.model.Day;
import edu.utsa.cs3443.quickmac.model.Food;

public class DayActivity extends AppCompatActivity {

    private Day currentDay;
    private TextView foodContentsView, macrosCountView, proteinCountView, calorieCountView, fatCountView, sugarCountView, fiberCountView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_day);

        initializeDay();
        initializeViews();
        updateDayDisplay();

        Button addFoodButton = findViewById(R.id.btnAddFoodItem);
        addFoodButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DayActivity.this, NewFoodActivity.class);
                startActivityForResult(intent, 1); // Request code 1 for adding food
            }
        });

        Button hallOfRecordsButton = findViewById(R.id.btnHallOfRecords);
        hallOfRecordsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DayActivity.this, LogbookActivity.class);
                startActivity(intent);
            }
        });
    }

    private void initializeDay() {
        // This method should initialize the currentDay object
        String todayDate = "04-22-2024";  // Example date, should be dynamically set
        currentDay = new Day(todayDate);
    }

    private void initializeViews() {
        foodContentsView = findViewById(R.id.food_contents);
        macrosCountView = findViewById(R.id.macros_dailyCount);
        proteinCountView = findViewById(R.id.protein_dailyCount);
        calorieCountView = findViewById(R.id.calorie_dailyCount);
        fatCountView = findViewById(R.id.fat_dailyCount);
        sugarCountView = findViewById(R.id.sugar_dailyCount);
        fiberCountView = findViewById(R.id.fiber_dailyCount);
    }

    private void updateDayDisplay() {
        StringBuilder foodDetails = new StringBuilder();
        int totalCalories = 0;
        double totalFat = 0, totalProtein = 0, totalCarbs = 0, totalSugar = 0, totalFiber = 0;

        for (Food food : currentDay.getFoods()) {
            if (foodDetails.length() > 0) foodDetails.append("\n");  // Add a newline between food entries
            foodDetails.append(food.getName())
                    .append(" - Calories: ").append(food.getCalories())
                    .append(", Fat: ").append(food.getFat()).append("g")
                    .append(", Protein: ").append(food.getProtein()).append("g")
                    .append(", Carbs: ").append(food.getCarbs()).append("g")
                    .append(", Sugar: ").append(food.getSugar()).append("g")
                    .append(", Fiber: ").append(food.getFiber()).append("g");

            // Sum up totals for the day
            totalCalories += food.getCalories();
            totalFat += food.getFat();
            totalProtein += food.getProtein();
            totalCarbs += food.getCarbs();
            totalSugar += food.getSugar();
            totalFiber += food.getFiber();
        }

        // Update the display with the information from currentDay
        foodContentsView.setText("Foods today: \n" + foodDetails.toString());
        macrosCountView.setText("Total Macros: " + totalCarbs + "g");
        proteinCountView.setText("Total Protein: " + totalProtein + "g");
        calorieCountView.setText("Total Calories: " + totalCalories);
        fatCountView.setText("Total Fat: " + totalFat + "g");
        sugarCountView.setText("Total Sugar: " + totalSugar + "g");
        fiberCountView.setText("Total Fiber: " + totalFiber + "g");
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            // Assuming you pass back a Food object
            Food newFood = (Food) data.getSerializableExtra("newFood");
            currentDay.addFood(newFood);
            updateDayDisplay();  // Refresh the UI with the new food item
        }
    }
}
