package edu.utsa.cs3443.quickmac;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import edu.utsa.cs3443.quickmac.LogbookAdapter;
import edu.utsa.cs3443.quickmac.model.Day;
import edu.utsa.cs3443.quickmac.model.Logbook;

public class LogbookActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private LogbookAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logbook);

        recyclerView = findViewById(R.id.recyclerViewLogbook);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Assuming Logbook is initialized somewhere globally or passed via intent
        Logbook logbook = new Logbook(); // Placeholder
        List<Day> lastSevenDays = logbook.getDays().subList(Math.max(logbook.getDays().size() - 7, 0), logbook.getDays().size());
        String totalSummary = "Summary of last 7 days: ";  // Append calculated values
        adapter = new LogbookAdapter(lastSevenDays, totalSummary);
        recyclerView.setAdapter(adapter);

        Button btnDailyOverview = findViewById(R.id.btnDailyOverview);
        btnDailyOverview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LogbookActivity.this, DayActivity.class);
                startActivity(intent);
            }
        });
    }
}